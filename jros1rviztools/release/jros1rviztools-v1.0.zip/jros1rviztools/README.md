**jros1rviztools** - Java module which allows to interact with RViz in ROS1 (Robot Operating System).

# Download

[Release versions](https://github.com/pinorobotics/jros1rviztools/releases)

Or you can add dependency to it as follows:

Gradle:

```
dependencies {
    implementation 'io.github.pinorobotics:jros1rviztools:1.0'
}
```

# Documentation

[Documentation](http://pinoweb.freetzi.com/jrosrviztools)

[Development](DEVELOPMENT.md)

# Contributors

aeon_flux <aeon_flux@eclipso.ch>
